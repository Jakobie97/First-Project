/*
  Coded by: Jacob Tyler stoockwell
  Pizza joint ordering program project from Codecademy
*/

let orderCount = 0;

const orderPizza = (toppings, crustType) =>{
orderCount++;
  
  /*prompt output or users
 var toppings = prompt('What kind of toppings would you like on your pizza?')
 var crustType = prompt('What kind of crust would you like on your pizza?')
 */
  
  console.log('Order: '  + toppings + ' pizza with ' + crustType + ' crust'); // Output i.e: Order: cheese pizza with regular crust
};

orderPizza('pepperoni', 'thick');
orderPizza('Cheese','regular');
orderPizza('peperoni', 'stuffed');

const getSubTotal = () => {
  return orderCount * 7.5; //Multiplies x number in order to the defualt price
};

const getTax = () => {
  return getSubTotal() * 0.11; // calculates the tax
};

const getTotal = () => {
  return getTax() + getSubTotal();  // Adds tax to subtotal
}

//total cost output
console.log('Total: $' + getTotal());